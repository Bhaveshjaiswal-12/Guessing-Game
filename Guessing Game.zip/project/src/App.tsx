import React, { useState } from 'react';
import { useGameContract } from './hooks/useGameContract';
import { Wallet, Moon, Sun, DollarSign, Trophy, Dice1 as Dice, Github, Twitter, Disc as Discord, Heart } from 'lucide-react';
import { Toaster } from 'react-hot-toast';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [betAmount, setBetAmount] = useState('0.01');
  const [guess, setGuess] = useState('');
  const { 
    account, 
    prizePool, 
    winner, 
    isLoading,
    isConnecting,
    connectWallet, 
    startGame, 
    submitGuess 
  } = useGameContract();

  const handleGuessSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const guessNum = parseInt(guess);
    if (guessNum >= 1 && guessNum <= 100) {
      submitGuess(guessNum);
      setGuess('');
    }
  };

  return (
    <div className={`min-h-screen flex flex-col ${darkMode ? 'dark' : ''}`}>
      {/* Hero Section */}
      <div className="hero-pattern relative">
        <div className="overlay absolute inset-0" />
        <div className="container mx-auto px-4 py-16 relative">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-4 text-white">
              Crypto Number Game
            </h1>
            <p className="text-xl text-gray-200 mb-8 max-w-2xl mx-auto">
              Test your luck and intuition! Guess the right number to win the entire prize pool. 
              Join thousands of players in this exciting blockchain game.
            </p>
            {!account && (
              <button
                onClick={connectWallet}
                disabled={isConnecting}
                className="btn-primary flex items-center gap-3 text-lg mx-auto"
              >
                <Wallet className="w-6 h-6" />
                {isConnecting ? 'Connecting...' : 'Connect Wallet'}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="gradient-bg flex-grow">
        <div className="container mx-auto px-4 py-12 relative">
          <div className="absolute top-4 right-4 flex gap-4">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-3 rounded-full glass hover:scale-110 transition-transform duration-200"
              aria-label="Toggle theme"
            >
              {darkMode ? 
                <Sun className="text-yellow-400 w-6 h-6" /> : 
                <Moon className="text-gray-600 w-6 h-6" />
              }
            </button>
          </div>

          {account && (
            <div className="max-w-4xl mx-auto space-y-8">
              <div className="card">
                <div className="flex items-center gap-4">
                  <div className={`flex-1 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    <p className="text-sm opacity-70">Connected Wallet</p>
                    <p className="font-mono text-lg">
                      {account.slice(0, 6)}...{account.slice(-4)}
                    </p>
                  </div>
                  <div className={`text-right ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                    <p className="text-sm opacity-70">Current Prize Pool</p>
                    <p className="text-2xl font-bold">{prizePool} ETH</p>
                  </div>
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="card">
                  <div className="flex items-center gap-3 mb-6">
                    <DollarSign className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-gray-900'}`} />
                    <h2 className={`text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                      Start New Game
                    </h2>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        Bet Amount (ETH)
                      </label>
                      <input
                        type="number"
                        value={betAmount}
                        onChange={(e) => setBetAmount(e.target.value)}
                        step="0.01"
                        min="0.01"
                        className="input-field"
                      />
                    </div>
                    <button
                      onClick={() => startGame(betAmount)}
                      disabled={isLoading}
                      className="btn-success w-full flex items-center justify-center gap-2"
                    >
                      <Dice className="w-5 h-5" />
                      {isLoading ? 'Processing...' : 'Start New Game'}
                    </button>
                  </div>
                </div>

                <div className="card">
                  <div className="flex items-center gap-3 mb-6">
                    <Trophy className={`w-6 h-6 ${darkMode ? 'text-white' : 'text-gray-900'}`} />
                    <h2 className={`text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                      Make a Guess
                    </h2>
                  </div>
                  <form onSubmit={handleGuessSubmit} className="space-y-4">
                    <div>
                      <label className={`block text-sm font-medium mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>
                        Your Guess (1-100)
                      </label>
                      <input
                        type="number"
                        value={guess}
                        onChange={(e) => setGuess(e.target.value)}
                        placeholder="Enter your guess"
                        min="1"
                        max="100"
                        className="input-field"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={isLoading || !guess}
                      className="btn-primary w-full"
                    >
                      {isLoading ? 'Processing...' : 'Submit Guess'}
                    </button>
                  </form>
                </div>
              </div>

              {winner !== '0x0000000000000000000000000000000000000000' && (
                <div className="card">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className={`text-xl font-semibold mb-2 flex items-center gap-2 ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                        <Trophy className="w-6 h-6 text-yellow-500" />
                        Last Winner
                      </h2>
                      <p className={`font-mono ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                        {winner.slice(0, 6)}...{winner.slice(-4)}
                      </p>
                    </div>
                    <div className="text-yellow-500 animate-pulse">
                      <Trophy className="w-12 h-12" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className={`py-8 ${darkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-800'}`}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">About the Game</h3>
              <p className="text-sm opacity-75">
                A decentralized number guessing game built on Ethereum. Test your luck and win ETH prizes!
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="footer-link">How to Play</a>
                </li>
                <li>
                  <a href="#" className="footer-link">Terms & Conditions</a>
                </li>
                <li>
                  <a href="#" className="footer-link">Privacy Policy</a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Connect With Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="footer-link">
                  <Github className="w-6 h-6" />
                </a>
                <a href="#" className="footer-link">
                  <Twitter className="w-6 h-6" />
                </a>
                <a href="#" className="footer-link">
                  <Discord className="w-6 h-6" />
                </a>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700 text-center">
            <p className="text-sm flex items-center justify-center gap-2">
              Made with <Heart className="w-4 h-4 text-red-500" /> by Crypto Number Game Team
            </p>
          </div>
        </div>
      </footer>

      <Toaster 
        position="bottom-right"
        toastOptions={{
          style: {
            background: darkMode ? '#374151' : '#ffffff',
            color: darkMode ? '#ffffff' : '#1f2937',
          },
        }}
      />
    </div>
  );
}

export default App;