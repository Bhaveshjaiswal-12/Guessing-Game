export const CONTRACT_ADDRESS = '0x0a58eE83Ad4b12c65a031C350086545a93c04122';

export const GAME_ABI = [
  "function startGame() external payable",
  "function guessNumber(uint8 guess) external",
  "function getPrizePool() external view returns (uint256)",
  "function getWinner() external view returns (address)",
  "event GameStarted(address player, uint256 prizePool)",
  "event GuessSubmitted(address player, uint8 guess)",
  "event GameWon(address winner, uint256 prize)"
];