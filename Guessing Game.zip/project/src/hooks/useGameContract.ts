import { useState, useCallback, useEffect } from 'react';
import { ethers, BrowserProvider, Contract } from 'ethers';
import { CONTRACT_ADDRESS, GAME_ABI } from '../contracts/GameABI';
import toast from 'react-hot-toast';

export function useGameContract() {
  const [account, setAccount] = useState<string>('');
  const [contract, setContract] = useState<Contract | null>(null);
  const [prizePool, setPrizePool] = useState<string>('0');
  const [winner, setWinner] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  const connectWallet = useCallback(async () => {
    if (isConnecting) {
      toast.error('Connection already in progress. Please check MetaMask.');
      return;
    }
    
    try {
      setIsConnecting(true);
      
      if (!window.ethereum) {
        toast.error('Please install MetaMask!');
        return;
      }

      const provider = new BrowserProvider(window.ethereum);
      const accounts = await provider.send('eth_requestAccounts', []);
      const signer = await provider.getSigner();
      const gameContract = new Contract(CONTRACT_ADDRESS, GAME_ABI, signer);

      setAccount(accounts[0]);
      setContract(gameContract);
      
      // Initial data fetch
      const pool = await gameContract.getPrizePool();
      setPrizePool(ethers.formatEther(pool));
      
      const currentWinner = await gameContract.getWinner();
      setWinner(currentWinner);

      // Listen for account changes
      window.ethereum.on('accountsChanged', (newAccounts: string[]) => {
        if (newAccounts.length === 0) {
          setAccount('');
          setContract(null);
          setPrizePool('0');
          setWinner('');
          toast.info('Wallet disconnected');
        } else {
          setAccount(newAccounts[0]);
          toast.success('Account changed');
        }
      });

      // Listen for chain changes
      window.ethereum.on('chainChanged', () => {
        window.location.reload();
      });

      toast.success('Wallet connected successfully!');
    } catch (error: any) {
      if (error?.code === -32002) {
        toast.error('Connection request pending. Please check MetaMask.');
      } else if (error?.code === 4001) {
        toast.error('Connection rejected. Please try again.');
      } else {
        toast.error('Failed to connect wallet');
        console.error(error);
      }
    } finally {
      setIsConnecting(false);
    }
  }, [isConnecting]);

  const startGame = async (amount: string) => {
    if (!contract) return;
    setIsLoading(true);
    try {
      const tx = await contract.startGame({
        value: ethers.parseEther(amount)
      });
      await tx.wait();
      toast.success('Game started successfully!');
      
      // Update prize pool
      const pool = await contract.getPrizePool();
      setPrizePool(ethers.formatEther(pool));
    } catch (error) {
      toast.error('Failed to start game');
      console.error(error);
    }
    setIsLoading(false);
  };

  const submitGuess = async (guess: number) => {
    if (!contract) return;
    setIsLoading(true);
    try {
      const tx = await contract.guessNumber(guess);
      await tx.wait();
      toast.success('Guess submitted!');
      
      // Update winner and prize pool
      const currentWinner = await contract.getWinner();
      setWinner(currentWinner);
      const pool = await contract.getPrizePool();
      setPrizePool(ethers.formatEther(pool));
    } catch (error) {
      toast.error('Failed to submit guess');
      console.error(error);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    if (contract) {
      contract.on('GameStarted', (player, prizePool) => {
        setPrizePool(ethers.formatEther(prizePool));
        toast.success(`New game started by ${player}`);
      });

      contract.on('GameWon', (winner, prize) => {
        setWinner(winner);
        setPrizePool('0');
        toast.success(`Game won by ${winner}!`);
      });

      return () => {
        contract.removeAllListeners();
        // Clean up ethereum listeners
        if (window.ethereum) {
          window.ethereum.removeAllListeners('accountsChanged');
          window.ethereum.removeAllListeners('chainChanged');
        }
      };
    }
  }, [contract]);

  return {
    account,
    prizePool,
    winner,
    isLoading,
    isConnecting,
    connectWallet,
    startGame,
    submitGuess
  };
}